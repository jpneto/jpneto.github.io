package dataStructures;

import java.util.*;

/**
 * <p>Titulo: Uma implementa�ao din�mica da Tabela</p>
 * <p>Descri��o: Esta implementa�ao usa fun��es de Dispers�o para acesso
                 extremamente r�pido ao seus conte�do -> Hash Table.
                 Para al�m disso, utiliza a no��o de listas ligadas
                 para resolver problemas de colis�es.</p>
 * @version 1.0
 */

public class HashTableList implements Table,Cloneable {

  private int N;              // A dimens�o da tabela
  private int length;           // Quantos elementos existem na tabela
  private DList[] table;   // O vector que guarda a tabela
  private HashFunction h;     // A fun��o de dispers�o

  public HashTableList( HashFunction h1, int length ) {
    h = h1;
    N = length;
    table = new DList[N];
    for(int i=0;i<N;i++)
      table[i] = new DList();
  }

  public HashTableList( HashFunction h1 ) {
    this(h1,101);
  }

  public Table empty() {
    return new HashTableList(h);
  }

  public boolean isEmpty() {
    return length == 0;
  }

  /**
   * Devolve a posi�ao da chave (se existir)
   * @param key A chava a procurar
   * @return A posi��o de uma dada chave, ou -1 se nao existir
   */

  //@ensures !contains(key) ==> \result == -1;
  //@ensures  contains(key) ==> \result >=  0;
  private int searchPos(Object key) {
    int pos    = h.hashValue(key) % N;

    return table[pos].contains(new HashRegister(null,key)) ? pos : -1;
  }

  public boolean contains(Object key) {
    return searchPos(key) >= 0;
  }

  public void insert(Object item, Object key) {
    int pos = h.hashValue(key) % N;

    table[pos].addBegin(new HashRegister(item,key));
    length++;
  }

  public Object retrieve(Object key) {
    int pos = h.hashValue(key) % N;

    return ((HashRegister)(table[pos].get(table[pos].indexOf(key)))).item;
  }

  public void remove(Object key) {
    table[searchPos(key)].remFirst(key);
    length--;
  }

  /**
   * Traduz a estrutura da tabela numa string
   * @return a string que descreve a tabela
   */
  public String verbose() {
    String s="[| ";

    for(int i=0;i<N;i++)
      s += table[i] == null ? "[]" : table[i].toString() + ",";
    return s.substring(0,s.length()-1) + " |]";
  }

  /**
   * Traduz a tabela numa string
   * @return a string que descreve a tabela
   */
  public String toString() {
    String s="[| ";

    for(int i=0;i<N;i++)
      if (table[i] != null) {
          String t = table[i].toString();
          s += t.substring(1,t.length()-1) + ",";
        }
    return s.substring(0,s.length()-1) + " |]";
  }

  public Object clone() {
    HashTableList cp = new HashTableList(h,N);

    for(int i=0;i<N;i++)
      cp.table[i] = (DList)(table[i].clone());
    return cp;
  }

//note: to-do
  public boolean equals(Table t) { return true; }

  public Iterator iterator() {
     return new TableIterator();
  }

  private class TableIterator implements Iterator {
    public Object next() {
      return null;
    }

    public boolean hasNext() {
      return false;
    }

    public void remove() {
      throw new UnsupportedOperationException();
    }
  }

  //*************************************************************
  public static void main(String[] args) {

    HashTableList  ht = new HashTableList(new HashString(), 5);

    ht.insert("joao","a");
    ht.insert("luis","b");
    ht.insert("ana","c");
    ht.insert("tiago","d");
    ht.insert("vasco","e");
    ht.insert("beatriz","f");
    ht.insert("gra�a","g");
    HashTableList c = (HashTableList)(ht.clone());
    ht.insert("qw","h");
    System.out.println(c);
    System.out.println(ht);

  }
} // endClass HashTableList
