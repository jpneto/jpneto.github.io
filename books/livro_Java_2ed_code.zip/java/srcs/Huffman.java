package dataStructures;

/**
 * Classe local auxiliar na codifica�ao de Huffman
 * Guarda a informa�ao necess�ria em cada n� da �rvore de Huffman,
 * nomeadamente, quais os simbolos incluidos nesse n� (guardados numa
 * �rvore bin�ria DBinTree) e qual a sua frequ�ncia.
 *
 * @author Joao Neto
 * @version 1.0
 */
class HuffNode implements Comparable {
  int      freq;
  DBinTree tree;

  public HuffNode(String elems) {
    this(elems, 0, new DBinTree(), new DBinTree());
  }

  public HuffNode(String elems, int freq, DBinTree left, DBinTree right) {
    this.freq  = freq;
    this.tree  = new DBinTree(elems, left, right);
  }

  public String getElems() {
    return tree.root()+"";
  }

  public int compareTo(Object other) {
    if (freq == ((HuffNode)other).freq)
      return 0;
    return freq < ((HuffNode)other).freq ? -1 : 1;
  }

  public String toString() {
    return "(" + freq + "," + tree.root() + ")";
  }
} //end Class HuffNode
///////////////////////////////////////////////////////////////

/**
 * A classe que implementa a codifica�ao de Huffman (com algoritmo ganancioso)
 *
 * @author Joao Neto
 * @version 1.0
 */
public class Huffman {

  private DBinTree huffmanTree;

  /**
   * Devolver a �rvore de Huffman actual
   * @return a �rvore actual
   */
  public DBinTree getHuffmanTree() {
    return huffmanTree;
  }

  /*
   * Construir a �rvore de Huffman a partir de uma frase
   * @param s a mensagem original
   */
  private DBinTree makeHuffmanTree(String s) {

    //***** criar vector das frequencias baseado na string dada
    HuffNode[] frequences = new HuffNode[256];
    for(int i=0;i<frequences.length;i++)  // criar n�s
      frequences[i] = new HuffNode(String.valueOf((char)i));

    for(int i=0;i<s.length();i++)  // percorrer 's' e calcular frequencias
      frequences[(int)(s.charAt(i))].freq--;

    Sort.insert(frequences); // ordenar por frequencia

    //***** criar o amontoado baseado nas frequencias
    VHeap pQueue = new VHeap();
    for(int i=0;frequences[i].freq!=0;i++)
      pQueue.insert(frequences[i]);

    //***** criar a �rvore de huffman
    while (pQueue.length()>1) {
      HuffNode first = (HuffNode)pQueue.root();
      pQueue.remRoot();
      HuffNode second = (HuffNode)pQueue.root();
      pQueue.remRoot();
                       // substituir os dois n�s anteriores por um novo n�
      HuffNode newNode = new HuffNode(first.getElems() + second.getElems(),
                                      first.freq  + second.freq,
                                      first.tree,
                                      second.tree);
      pQueue.insert(newNode);
    }

    return ((HuffNode)(pQueue.root())).tree;
  }

  //////////////////////////////////////////

  /*
   * O char c pertence � string s?
   * @param s a string onde procurar
   * @param c o char a procurar
   * @return TRUE se c esta incluido em s
   */
  private boolean haveChar(String s, char c) {
    for(int i=0;i<s.length();i++)
      if (s.charAt(i) == c)
        return true;
    return false;
  }

  //////////////////////////////////////////

  /**
   * Devolver a codifica�ao bin�ria de um char
   * @param c o simbolo em quest�o
   * @return a codifica�ao bin�ria
   */
  public String getCode(char c) {
    String result = "";
    BinTree aux = huffmanTree;
    while (((String)(aux.root())).length()>1)
      if (haveChar(( (String)(aux.left().root())), c)) {
        aux = aux.left();
        result += "0";
      } else {
        aux = aux.right();
        result += "1";
      }
    return result;
  }

  //////////////////////////////////////////
  /**
   * Codificar uma string a partir da �rvore de Huffman  actual
   * @param s a mensagem original
   * @return a mensagem codificada
   */
  public String encode(String s) {
    String result="";
    huffmanTree = makeHuffmanTree(s);
    for(int i=0;i<s.length();i++)
      result += getCode(s.charAt(i));
    return result;
  }

  //////////////////////////////////////////

  /**
   * Descodificar uma string a partir da �rvore de Huffman actual
   * @param s a mensagem codificada
   * @return a mensagem descodificada
   */
  public String decode(String s) {
    String result="";
    BinTree aux = huffmanTree;

    for(int i=0;i<s.length();i++) {
      if (s.charAt(i)=='0')
        aux = aux.left();
      else // se n�o � zero, � um
        aux = aux.right();

      if (aux.isLeaf()) {
        result += (String)(aux.root());
        aux = huffmanTree;  // preparar para descodificar o prox. char
      }
    } //for(i)

    return result;
  }

  //////////////////////////////////////////
  // Para testes apenas
  //////////////////////////////////////////
  public static void main(String[] args) {

    Huffman h = new Huffman();
    String original = "abcbdaaeffaaaaaaaaaaaaaaaaaaffbbbbbaaaaaaaaaaeeeeeeff";
    String coded = h.encode(original);
    System.out.println("zipped " + coded.length() + "/" + original.length()*8 + ":" + coded);
    System.out.println("\n"+h.getHuffmanTree());
    System.out.println("a "+h.getCode('a'));
    System.out.println("b "+h.getCode('b'));
    System.out.println("c "+h.getCode('c'));
    System.out.println("d "+h.getCode('d'));
    System.out.println("e "+h.getCode('e'));
    System.out.println("f "+h.getCode('f'));
    System.out.println("g "+h.getCode('g'));
    System.out.println("decode: " + h.decode(coded));
  }
} //end Class Huffman