package dataStructures;

/**
 * <p>Titulo: A interface do TDA Hashable</p>
 * <p>Descri��o: Necess�rio a elementos usados em fun��es de dispers�o</p>
 * @version 1.0
 */

public interface HashFunction {

  /**
   * Calcula o valor de dispers�o de uma dada chave
   * @param key A chave a ser calculada
   * @return O valor dessa chave
   */
  //@ requires isHashable(key);
  int hashValue(Object key);

  /**
   * Verifica se um dado objecto tem valor de dispers�o
   * @param key A chave a verificar
   * @return TRUE se tem valor de dispers�o, FALSE c.c.
   */
  /*@ pure @*/ boolean isHashable(Object key);

  /**
   * Calcula o n-�simo valor depois de (n-1) colis�es, em rela�ao
   * � �ltima chave inquirida.
   * @return O pr�ximo valor
   */
  int nextValue();

} // endInterface HashFunction