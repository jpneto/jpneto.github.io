package dataStructures;

/**
 * <p>Titulo: Uma implementa�ao vectorial da Pilha Ilimitada</p>
 * <p>Descri��o: Esta implementa�ao usa um vector de dimens�o crescente</p>
 * @version 1.0
 */

public class VStack implements Stack,Cloneable {

  private final int  DELTA = 128;
  private Object[] theStack;
  private int      theTop;

  public VStack() {
    theStack = new Object[DELTA];
    theTop   = -1;
  }

  public Stack empty() {
    return new VStack();
  }

  public boolean isEmpty() {
    return theTop == -1;
  }

  /**
   * Increments the structure length (adds 'DELTA' new slots)
   */
  private void grow() {
    Object[] newStack = new Object[theStack.length + DELTA];

    for(int i=0;i<theStack.length;i++)
      newStack[i] = theStack[i];

    theStack = newStack;
  }

  public void push(Object item) {
    if (theTop+1 == theStack.length)
       grow();

    theStack[++theTop] = item;
  }

  public Object top() {
    return theStack[theTop];
  }

  public void pop() {
    theStack[theTop--] = null;
  }

  public boolean equals(Stack s) {
    int    i = theTop;
    Stack cp = (Stack)(s.clone());

    while (!cp.isEmpty()) {
      if (i<0 || !theStack[i].equals(cp.top()))
        return false;
      cp.pop();
      i--;
    }

    return i<0;
  }

  public Object clone() {
    VStack cp = new VStack();

    cp.theStack = new Object[theStack.length];

    for(int i=0;i<=theTop;i++)
      cp.theStack[i] = theStack[i];
    cp.theTop = theTop;
    return cp;
  }

  public String toString() {
    if (this.isEmpty())
      return "[]";

    String s = "[" + theStack[0];
    for(int i=1;i<=theTop;i++)
      s += "," + theStack[i];

    return s + "]>";
  }

  //********************************************************************
  public static void main(String[] args) {
    VStack v1 = new VStack(),
           v2 = new VStack();

    v1.push(new Integer(3));
    v1.push(new Integer(4));
    v1.push(new Integer(5));
    v1.push(new Integer(6));
    v1.push(new Integer(7));
    v2.push(new Integer(1));
    v1.pop();

    System.out.println(v1 + " " + v2.clone());
    System.out.println(v1.equals(v2) ? "==" : "!=");
  }
}  // endClass VStack

