package dataStructures;

import java.io.*;
import java.util.*;

/**
 * <p>Titulo: An input/output interface</p>
 * @author Jo�o Neto
 * @version 1.0
 */
public class IO {

  private char io;
  private BufferedReader input  = null;
  private BufferedWriter output = null;

  public IO(String filename, char mode) throws IOException {
    io = mode;

    if (isInput())
      input  = new BufferedReader( new FileReader(filename) );
    else
      output = new BufferedWriter( new FileWriter(filename) );
  }

  //////////////////////////////////////////////////////

  public boolean isInput()  { return io=='r'; }
  public boolean isOutput() { return io=='w'; }

  //////////////////////////////////////////////////////

  public String readLine() throws IOException {
    if (isOutput())
      throw new IOException();

    return input.readLine();
  }

  public int readInt() throws IOException {
    if (isOutput())
      throw new IOException();

    return Integer.parseInt(input.readLine());
  }

  public double readDouble() throws IOException {
    if (isOutput())
      throw new IOException();

    return Double.parseDouble(input.readLine());
  }

  //////////////////////////////////////////////////////

  public void write(String s) throws IOException {
    if (isInput())
      throw new IOException();

    output.write(s);
  }

  public void write(int i)      throws IOException {  write(""+i);  }
  public void write(char c)     throws IOException {  write(""+c);  }
  public void write(double d)   throws IOException {  write(""+d);  }

  public void writeln(String s) throws IOException { write(s+"\r\n"); }
  public void writeln(int i)    throws IOException { writeln(""+i);   }
  public void writeln(char c)   throws IOException { writeln(""+c);   }
  public void writeln(double d) throws IOException { writeln(""+d);   }

  //////////////////////////////////////////////////////

  public void close() throws IOException {
    if (isInput())
      input.close();
    else
      output.close();
  }

  //////////////////////////////////////////////////////

  StringTokenizer st;
  String          stSps;
  boolean         hasNextTok = false;
  String          actualTok  = "";

  public void newTok(String separators) throws IOException {
    if (isOutput())
      throw new IOException();

    try {
      stSps      = separators;
      String line = input.readLine();
      if (line==null)
        throw new NoSuchElementException();
      st         = new StringTokenizer(line,stSps);
      actualTok  = st.nextToken();
      hasNextTok = true;
    } catch (NoSuchElementException e) {
      actualTok  = "";
      hasNextTok = false;
    }
  }

  public void newTok() throws IOException {
    newTok(" \n\t\r");
  }

  public boolean hasTok() {
    return hasNextTok;
  }

  public String getTok() {
    return actualTok;
  }

  public void nextTok() throws IOException {
    if (!hasNextTok)
      return;

    try {
      if (!st.hasMoreTokens()) {
        String line = input.readLine();
        if (line==null)
          throw new NoSuchElementException();
        st = new StringTokenizer(line,stSps);
      }
      actualTok  = st.nextToken();
    } catch (NoSuchElementException e) {
      actualTok  = "";
      hasNextTok = false;
    }
  }

  //////////////////////////////////////////////////////
  // DEFAULT STATIC METHODS FOR MONITOR AND KEYBOARD  //
  //////////////////////////////////////////////////////

  private static BufferedReader in;
  private static BufferedWriter out, err;

  static {
    in  = new BufferedReader( new InputStreamReader(System.in) );
    out = new BufferedWriter( new OutputStreamWriter(System.out) );
    err = new BufferedWriter( new OutputStreamWriter(System.err) );
  }

  public static char getChar() {
    while (true)
      try {
        return in.readLine().charAt(0);
      } catch (Exception e) {
        put("Expect char:");
      }
  }

  public static int getInt() {
    while (true)
      try {
        return Integer.parseInt(in.readLine());
      } catch (Exception e) {
        put("Expect integer:");
      }
  }

  public static double getDouble() {
    while (true)
      try {
        return Double.parseDouble(in.readLine());
      } catch (Exception e) {
        put("Expect double:");
      }
  }

  public static String getLine() {
    try {
      return in.readLine();
    } catch (Exception e) {
      return "";  // never reach here
    }
  }

  public static void put(String s) {
    try {
      out.write(s);
      out.flush();
    } catch (IOException e) {
      try {
        err.write("Unable to write: " + s);
      } catch (IOException e1) {};
    }
  }

  public static void put(int i)    { put(""+i); }
  public static void put(char c)   { put(""+c); }
  public static void put(double d) { put(""+d); }
  public static void nl()          { put("\n"); }

  //////////////////////////////////////////////////////
  // alguns exemplos

  public static void main(String[] agrs) throws IOException {

    // exemplos com ficheiros

    IO y = new IO("intest.txt",'r');

    int a    = y.readInt();
    double b = y.readDouble();
    String c = y.readLine();

    y.close();

    IO x = new IO("outtest.txt",'w');

    x.writeln("Test:"+a);
    x.writeln(b);
    x.writeln(c);

    x.close();

    // exemplos com monitor e teclado

    double d = IO.getDouble();
    IO.put(d+100);

    IO.nl();
    String s = IO.getLine();
    IO.put(s+"!");

    // exemplo com tokens

    IO t = new IO("tokens.txt",'r');

    for(t.newTok();t.hasTok();t.nextTok())
      IO.put(t.getTok() + "/");
  }

}