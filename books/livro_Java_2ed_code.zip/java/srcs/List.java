package dataStructures;

import java.util.*;

/**
 * <p>Titulo: A interface do TDA Lista</p>
 * <p>Descri��o: O desenho da Lista (List) com os respectivos contratos</p>
 * @version 1.0
 */

public interface List {

  //@ public invariant !isEmpty() ==> head() != null;

  /**
   * Criar uma lista vazia
   * @return uma lista vazia
   */

  //@ ensures \result.isEmpty();
  /*@ pure @*/ List empty();

  /**
   * A lista est� vazia?
   * @return TRUE se est� vazia, FALSE c.c.
   */
  /*@ pure @*/ boolean isEmpty();

  /**
   * Adicionar � lista um novo objecto
   * @param o a refer�ncia do objecto a adicionar
   */

  //@ requires o != null;
  //@ ensures head().equals(o);
  //@ ensures tail().equals((List)\old(clone()));
  void cons(Object o);

  /**
   * Devolver o elemento que est� no inicio da fila
   * @return a refer�ncia do primeiro elemento
   */

  //@ requires  !isEmpty();
  /*@ pure @*/ Object head();

  /**
   * Devolver o resto da lista
   * @return a refer�ncia para o resto da lista
   */

   //@ requires !isEmpty();
   /*@ pure @*/ List tail();

  /**
   * Calcular o n�mero de elementos da lista
   * @return o n�mero de elementos da lista
   */

  //@ ensures  isEmpty() ==> \result == 0;
  //@ ensures !isEmpty() ==> \result == 1 + tail().length();
  /*@ pure @*/ int length();

  /**
   * Descobrir o n-�simo elemento da lista
   * @param n a posi��o requerida
   * @return a refer�ncia para o n-�simo elemento
   */

  //@ requires n > 0 && length() >= n;
  //@ ensures n==1 ==> \result.equals(head());
  //@ ensures n!=1 ==> \result.equals(tail().get(n-1));
  /*@ pure @*/ Object get(int n);

  /**
   * Inserir no in�cio
   * @param o a refer�ncia do elemento a ser inserido
   */

  //@ requires  o != null;
  //@ ensures head().equals(o);
  //@ ensures tail().equals((List)\old(clone()));
  void addBegin(Object o);

  /**
   * Inserir no fim
   * @param o a refer�ncia do elemento a ser inserido
   */

  //@ requires  o != null;
  //@ ensures length() == \old(length()) + 1;
  //@ ensures get(length()).equals(o);
  //@ ensures (\forall int i; 1 <= i && i <= length()-1; ((List)\old(clone())).get(i).equals(get(i)));
  void addEnd(Object o);

  /**
   * Inserir na n-�sima posi��o
   * @param o a refer�ncia do elemento a ser inserido
   * @param n a posi��o de inser��o (n=1 insere no in�cio)
   */

  //@ requires  o != null;
  //@ requires  n > 0 &&  n <= length();
  //@ ensures length() == \old(length()) + 1;
  //@ ensures get(n).equals(o);
  //@ ensures (\forall int i; n <= i && i <= \old(length()); ((List)\old(clone())).get(i).equals(get(i+1)));
  //@ ensures (\forall int j; 1 <= j && j <= (n-1); ((List)\old(clone())).get(j).equals(get(j)));
  void add(Object o, int n);

  /**
   * Remover o primeiro elemento
   */

  //@ requires !isEmpty();
  //@ ensures equals(((List)\old(clone())).tail());
  void removeBegin();

  /**
   * Remover o �ltimo elemento
   */

  //@ requires !isEmpty();
  //@ ensures length() == \old(length()) - 1;
  //@ ensures (\forall int i; 1 <= i && i <= length()-1; ((List)\old(clone())).get(i).equals(get(i)));
  void removeEnd();

  /**
   * O objecto est� na lista?
   * @param o a refer�ncia do elemento a ser procurado
   * @return TRUE se o objecto existe, FALSE c.c.
   */

  //@ ensures \result == (!isEmpty() && (o.equals(head()) || tail().contains(o)));
  /*@ pure @*/ boolean contains(Object o);

  /**
   * Devolver a posi��o da primeira refer�ncia do objecto na lista, se
     o objecto n�o existir, devolve zero.
   * @param o a refer�ncia do objecto a procurar
   * @return a posi��o do 1� objecto igual a 'o', sen�o Zero
   */

  //@ requires o != null;
  //@ ensures !contains(o) ==> \result == 0;
  //@ ensures  contains(o) &&   o.equals(head())  ==> \result == 1;
  //@ ensures  contains(o) && !(o.equals(head())) ==> \result == 1 + tail().indexOf(o);
  /*@ pure @*/ int indexOf(Object o);

  /**
   * Remover a 1� ocorr�ncia de um elemento
   * @param o a refer�ncia do elemento que serve de compara��o para a remo��o
   */

  //@ requires o != null;
  //@ ensures \old(contains(o)) ==> length() == \old(length()) - 1;
  void remFirst(Object o);

  /**
   * Remover todas as ocorr�ncias de um elemento
   * @param o a refer�ncia do elemento que serve de compara��o para a remo��o
   */

  //@ requires o != null;
  //@ ensures !contains(o);
  void remAll(Object o);

  /**
   * Concatenar duas listas
   * @param l a lista a ser concatenada no fim desta lista
   */

  //@ requires l != null;
  //@ ensures length() == \old(length()) + l.length();
  //@ ensures (\forall int i; 1 <= i && i <= \old(length()); ((List)\old(clone())).get(i).equals(get(i)));
  //@ ensures (\forall int j; \old(length()) < j && j <= length(); get(j).equals(l.get(j-(\old(length())))));
  void concat(List l);

  /**
   * Inverter a lista
   */

  //@ ensures length() == \old(length());
  //@ ensures (\forall int i; 1 <= i && i <= length(); ((List)\old(clone())).get(i).equals(get(length()-i+1)));
  void reverse();

  /**
   * Sao as duas listas iguais?
   * @param l a lista a ser comparada
   * @return TRUE se this==o, FALSE c.c
   */

  //@ requires l != null;

  //@ ensures isEmpty() ==> \result == l.isEmpty();
  //@ ensures !isEmpty() ==> \result == (!(l.isEmpty()) && head().equals(l.head()) && tail().equals(l.tail()));
  /*@ pure @*/ boolean equals(List l);

  /**
   * Devolver uma c�pia da estrutura.
   * @return uma referencia para a c�pia
   */

  //@ also
  //@ ensures (\result != this) && equals((List)\result);
  /*@ pure @*/ Object clone();

}//endInterface List