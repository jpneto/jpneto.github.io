package dataStructures;

import java.util.*;

/**
 * <p>Titulo: A interface do TDA �rvore Bin�ria</p>
 * <p>Descri��o: O desenho da �rvore (BinTree) com os respectivos contratos</p>
 * @version 1.0
 */

public interface BinTree {

  // N�o � poss�vel ter objectos nulos numa �rvore n�o vazia
  //@ public invariant !isEmpty() ==> root() != null;

  /**
   * Cria uma �rvore vazia
   * @return uma �rvore vazia
   */

  //@ ensures \result.isEmpty();
  /*@ pure @*/ BinTree empty();

  /**
   * Devolve true se a �rvore est� vazia, sen�o false
   * @return Devolve TRUE se a estrutura est� vezia, FALSE c.c.
   */

  /*@ pure @*/ boolean isEmpty();

  /**
   * Constr�i uma �rvore
   * @param item A refer�ncia do objecto a ser guardado
   * @param left A refer�ncia da �rvore da esquerda
   * @param right A refer�ncia da �rvore da direita
   */

  //@ requires right != null && !right.isEmpty() ==> item.getClass() == right.root().getClass();
  //@ requires left != null && !left.isEmpty() ==> item.getClass() ==  left.root().getClass();
  //@ ensures item != null ==> !isEmpty();
  //@ ensures item != null ==> root().equals(item);
  //@ ensures item != null ==> left().equals(left);
  //@ ensures item != null ==> right().equals(right);
  void constr(Object item, BinTree left, BinTree right);

  /**
   * Devolve a informa��o da raiz da �rvore
   * @return A refer�ncia do objecto que est� na raiz
   */

  //@ requires !isEmpty();
  /*@ pure @*/ Object root();

  /**
   * Devolve a �rvore da esquerda
   * @return A refer�ncia da sub�rvore da esquerda
   */

  //@ requires !isEmpty();
  /*@ pure @*/ BinTree left();

  /**
   * Devolve a �rvore da direita
   * @return A refer�ncia da sub�rvore da direita
   */

  //@ requires !isEmpty();
  /*@ pure @*/ BinTree right();

  /**
   * Devolve o n�mero de elementos da �rvore
   * @return O n�mero de elementos da �rvore
   */

  //@ ensures  isEmpty() ==> \result == 0;
  //@ ensures !isEmpty() ==> \result == 1 + left().length() + right().length();
  /*@ pure @*/ int length();

  /**
   * Devolve a altura da �rvore (i.e., a dimens�o do maior caminho)
   * @return A altura da �rvore
   */

  //@ ensures  isEmpty() ==> \result == 0;
  //@ ensures !isEmpty() ==> \result == 1 + Math.max(left().height(), right().height());
  /*@ pure @*/ int height();

  /**
   * Verifica se � uma folha
   * @return TRUE se � uma folha, FALSE c.c.
   */

  //@ ensures \result == (!isEmpty() && left().isEmpty() && right().isEmpty());
  /*@ pure @*/ boolean isLeaf();

  /**
   * Verifica se duas �rvores s�o iguais
   * @param t A �rvore para ser comparada
   * @return TRUE se as duas �rvores s�o iguais (t�m a mesma estrutura e
            e guardam a mesma informa��o)
   */

  //@ requires t != null;
  //@ ensures isEmpty() ==> t.isEmpty();
  //@ ensures t.isEmpty() ==> isEmpty();
  //@ ensures !isEmpty() && !t.isEmpty() ==> \result == (root().equals(t.root()) && left().equals(t.left()) && right().equals(t.right()));
  /*@ pure @*/ boolean equals(BinTree t);

  /**
   * Atravessa a �rvore de forma prefixa
   * @param op O operador a ser executado em cada n�
   */

  //@ requires op != null;
  void prefix(Visitor op);

  /**
   * Atravessa a �rvore de forma infixa
   * @param op O operador a ser executado em cada n�
   */

  //@ requires op != null;
  void infix(Visitor op);

  /**
   * Atravessa a �rvore de forma sufixa
   * @param op O operador a ser executado em cada n�
   */

  //@ requires op != null;
  void sufix(Visitor op);

  /**
   * @return Um iterator para os elementos do conjunto (travessia por largura)
   */
  Iterator iterator();

  /**
   * Devolve uma copia da estrutura da �rvore. Nao copia os conteudos!
   * @return devolve uma referencia para a c�pia
   */
  //@ also
  //@ ensures (\result != this) && equals((BinTree)\result);
  /*@ pure @*/ Object clone();

}  // endInterface BinTree