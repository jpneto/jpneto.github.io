package dataStructures;

import java.util.*;

/**
 * <p>Title: Menu Class</p>
 * <p>Description: A helper class with menu utilities for testing purposes</p>
 * @author Jo�o Neto
 * @version 1.0
 */
public class Menu {

  private DList    list;
  private int      nextId=0;
  private Visitor op;

  private class MenuItem { // local class for internal use
    int    id;
    String text;

    public MenuItem(int id, String text) {
      this.id = id;
      this.text = text;
    }

    public String toString() {
      return id + ": " + text;
    }
  } //end local class MenuItem ////////////////////////////

  public Menu(Visitor op) {
    this.op = op;
    list    = new DList();
    list.addBegin(new MenuItem(nextId++, "Exit")); // default option (Exit)
  }

  // Executes a specific option from the given operator
  private void execute(int option) {
    op.visit(new Integer(option));
    if (op.result()!=null)   // if there's something to show...
      System.out.println(op.result());
  }

  // Show menu options
  private void show() {
    System.out.println("*** Choose a valid option ***");
    for(Iterator it = list.iterator(); it.hasNext(); )
      System.out.println(it.next());
    System.out.print("[0-" + (nextId-1) + "]? ");
  }

  /**
   * Add a new Menu entry
   * @param text The menu entry message
   */
  public void add(String text) {
    list.addEnd(new MenuItem(nextId++, text));
  }

  /**
   * Run menu until option "Exit" is chosen
   */
  public void run() {
    int option;

    do {
      show();
      option = IO.getInt();
      if (option>0 && option<nextId)
        execute(option);
    } while (option!=0);

    System.out.println("Bye...");
  }
}
