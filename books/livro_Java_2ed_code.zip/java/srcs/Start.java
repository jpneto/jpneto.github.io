package dataStructures;

/**
 * <p>Title: START Class</p>
 * <p>Description: Used only to start the Application</p>
 */

public class Start {

  private Start() {} // there should be no objects of this class

  public static void main(String[] args) throws Exception {

    Menu m = new Menu(new ListMenu());

    m.add("Add Begin");
    m.add("Add End");
    m.add("Rem Begin");
    m.add("Rem End");
    m.add("Size");
    m.add("Do Nothing");

//    m.run();

    System.out.println("ola".hashCode());
    System.out.println("ola".hashCode());
    System.out.println("olb".hashCode());
    System.out.println("olfads".hashCode());
    System.out.println("a".hashCode());
  }
}

////////////////////////////////////////////////
// exemplo de classe usada no Menu

class ListMenu implements Visitor {
  private Object result;
  private DList myList;

  public  ListMenu() {
    myList = new DList();
  }

  public void reset() {} // n�o usado mas necess�rio � interface

  public Object result() {  // para ser imprimido (se != null) ap�s
    return result;             //  a execu��o da op�ao escolhida no menu
  }

  public void visit(Object option) {

                // tem de ser a mesma ordem das op�oes adicionadas ao menu
    switch (((Integer)option).intValue()) {
      case 1:
        myList.addBegin(new Integer(IO.getInt()));
        result = myList;
        break;
      case 2:
        myList.addEnd(new Integer(IO.getInt()));
        result = myList;
        break;
      case 3:
        myList.removeBegin();
        result = myList;
        break;
      case 4:
        myList.removeEnd();
        result = myList;
        break;
      case 5:
        result = new Integer(myList.length());
        break;
      case 6:
        result = null;
        break;
    }
  }
}
