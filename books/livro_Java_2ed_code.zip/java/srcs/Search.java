package dataStructures;

public class Search {

  private Search() {}

  public static int serial (int[] v, int value) {
    for (int i=0;i<v.length;i++)
      if (v[i]==value)
        return i;
    return -1;
  }

  public static int binary (int[] v, int value) {
    return binary(v,value,0,v.length);
  }

  private static int binary (int[] v, int value, int begin, int length) {
    if (length<=0)
      return -1;

    int middle = begin + length/2;

    if (v[middle]==value)
      return middle;
    if (value<v[middle])
      return binary(v,value,begin,length/2);
    return binary(v,value,middle+1,(length-1)/2);
  }

  public static void main(String[] args) {
    int[] is = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};

    for (int i=1;i<=
         is.length;i++) {
      System.out.print(serial(is,i) + " ");
      System.out.print(binary(is,i) + ":");
    }
  }
}