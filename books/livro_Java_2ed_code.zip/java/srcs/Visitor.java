package dataStructures;

/**
 * <p>Titulo: A interface de um Visitor gen�rico</p>
 * <p>Descri��o: Um objecto deste tipo pode ser usado para realizar
                 uma sequencia de opera��es sobre uma estrutura de dados.
                 Por exemplo, numa travessia infixa de uma �rvore bin�ria</p>
 *
 * @author Jo�o Neto
 * @version 1.0
 */

public interface Visitor {
 /**
  * Executar a opera��o
  * @param info A refer�ncia da informa��o a ser tratada
  */
  void visit(Object info);

 /**
  * Devolver o resultado
  * @return O resultado da(s) visita(s)
  */
  Object result();
}