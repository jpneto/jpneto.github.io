package dataStructures;

class Fraction implements Comparable {
  private long n,d;

  Fraction(long n, long d) {
    this.n = n/Fraction.gcd(n,d);
    this.d = d/Fraction.gcd(n,d);
  }

  public Fraction sum(Fraction f) {
    long g = gcd(n*f.d+d*f.n, d*f.d);
    return new Fraction((n*f.d+d*f.n)/g, (d*f.d)/g);
  }

  public int compareTo(Object o) {
    if (n==((Fraction)o).n && d==((Fraction)o).d)
      return 0;
    return ((double)n/d) < ((double)((Fraction)o).n/((Fraction)o).d) ? -1 : 1;
  }

  public String toString() {
    return n + "/" + d;
  }

  private static long gcd(long n1, long n2) {
    return n2==0 ? n1 : gcd(n2,n1%n2);
  }
} //end Class Frac

///////////////////////////////////////////////////////

public class Greedy {

  /**
   * Each fraction can be expressed as a sum of different fractions with unit
   * numerators. Such representations have been used by the ancient Egyptians.
   * A given fraction might have more than one Egyptian representation.
   * A greedy algorithm, for finding such a representation, can at each stage
   * add to the sum the largest unit fraction which does not cause the sum to
   * exceed the fraction. Fibonacci proved that this greedy algorithm is
   * guaranteed to halt.
   *
   * @param f the fraction to decompose
   * @return an array of fractions with the egyptian representation
   */

  //@ requires f.compareTo(new Frac(2,1)) < 0;
  public static DList egypt(Fraction f) {
    DList resultList = new DList();
    Fraction nextF, tempF, sumFs = new Fraction(0,1);
    long  den=1;

    do {
      nextF = new Fraction(1,den++);
      tempF = sumFs.sum(nextF);
      if (tempF.compareTo(f) <= 0) {
        sumFs = tempF;
        resultList.addEnd(nextF);
      }
    } while (tempF.compareTo(f) != 0);

    return resultList;
  }

  /////////////////////////////////////////////////

  public static void main(String[] args) {

    System.out.print(Greedy.egypt(new Fraction(8,5)));
  }
}